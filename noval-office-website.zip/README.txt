# Noval Office Website
## مكتب نوفال للدراسة بالخارج

### Website Features | مميزات الموقع:
- ✅ Bilingual (Arabic/English) | موقع ثنائي اللغة
- ✅ University Search & Filter | البحث والتصفية في الجامعات
- ✅ Scholarships Database | قاعدة بيانات المنح الدراسية
- ✅ Student Registration Form | نموذج تسجيل الطلاب
- ✅ WhatsApp Integration | تكامل واتساب
- ✅ Responsive Design | تصميم متجاوب
- ✅ Brown & Beige Color Scheme | ألوان بني وبيج

### How to Deploy | كيفية النشر:

#### Option 1: Netlify (Free) | الخيار الأول: نيتليفاي (مجاني)
1. Go to https://www.netlify.com
2. Drag and drop the website folder
3. Your site will be live instantly!

#### Option 2: GitHub Pages (Free) | الخيار الثاني: جيثب بيجز (مجاني)
1. Create a GitHub repository
2. Upload these files
3. Enable GitHub Pages in settings

#### Option 3: Traditional Hosting | الخيار الثالث: استضافة تقليدية
1. Buy domain: novaloffice.com
2. Buy hosting from Hostinger/Bluehost
3. Upload files via FTP

### Contact Information | معلومات التواصل:
- Address: 24 Abdel Rahman El Barqouqi St., Egypt
- Email: novaloffice22@gmail.com
- Phone/WhatsApp: +20 150 032 9000

### Admin Features | ميزات الإدارة:
- Student applications are saved in browser localStorage
- To view applications: Open browser console and type: `exportApplications()`
- To clear data: Type `clearApplications()`

### File Structure | هيكل الملفات:
```
noval-office/
├── index.html
├── css/
│   └── style.css
├── js/
│   ├── data.js
│   └── main.js
└── images/
    └── logo.svg
```

© 2026 Noval Office for Education Abroad
