// ================================
// Noval Office - Main JavaScript
// ================================

let currentLang = 'ar';

// DOM Content Loaded
document.addEventListener('DOMContentLoaded', function() {
    initUniversities();
    initScholarships();
    initCounters();
    initScrollAnimations();
    initNavigation();
    initFormHandling();
    initSearchFilter();
});

// Language Switcher
function switchLanguage(lang) {
    currentLang = lang;

    // Update buttons
    document.querySelectorAll('.lang-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    document.getElementById('btn-' + lang).classList.add('active');

    // Update all elements with data attributes
    document.querySelectorAll('[data-ar][data-en]').forEach(el => {
        if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
            el.placeholder = el.getAttribute('data-' + lang + '-placeholder') || el.getAttribute('data-' + lang);
        } else {
            el.textContent = el.getAttribute('data-' + lang);
        }
    });

    // Update select options
    document.querySelectorAll('select option[data-ar][data-en]').forEach(opt => {
        opt.textContent = opt.getAttribute('data-' + lang);
    });

    // Update direction
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = lang;

    // Re-render dynamic content
    renderUniversities();
    renderScholarships();

    // Update search placeholder
    const searchInput = document.getElementById('uniSearch');
    if (searchInput) {
        searchInput.placeholder = lang === 'ar' ? 'ابحث عن جامعة...' : 'Search for a university...';
    }
}

// Universities Functions
function initUniversities() {
    renderUniversities();
}

function renderUniversities() {
    const grid = document.getElementById('universitiesGrid');
    if (!grid) return;

    const activeFilter = document.querySelector('.filter-btn.active');
    const filter = activeFilter ? activeFilter.getAttribute('data-filter') : 'all';
    const searchTerm = document.getElementById('uniSearch')?.value.toLowerCase() || '';

    let filtered = universitiesData;

    if (filter !== 'all') {
        filtered = filtered.filter(u => u.country === filter);
    }

    if (searchTerm) {
        filtered = filtered.filter(u => 
            u.name.toLowerCase().includes(searchTerm) ||
            u.nameAr.includes(searchTerm) ||
            u.countryAr.includes(searchTerm) ||
            u.cityAr.includes(searchTerm)
        );
    }

    grid.innerHTML = filtered.map(uni => `
        <div class="university-card fade-in">
            <div class="university-image">
                <img src="${uni.image}" alt="${currentLang === 'ar' ? uni.nameAr : uni.name}" onerror="this.style.display='none'; this.parentElement.innerHTML='<i class=\'fas fa-university uni-icon\'></i>';">
                <span class="university-badge">${uni.ranking}</span>
            </div>
            <div class="university-info">
                <h3>${currentLang === 'ar' ? uni.nameAr : uni.name}</h3>
                <div class="university-location">
                    <i class="fas fa-map-marker-alt"></i>
                    <span>${currentLang === 'ar' ? uni.cityAr : uni.city}, ${currentLang === 'ar' ? uni.countryAr : uni.country}</span>
                </div>
                <div class="university-details">
                    ${(currentLang === 'ar' ? uni.majorsAr : uni.majors).slice(0, 3).map(m => `<span>${m}</span>`).join('')}
                </div>
                <div class="university-rating">
                    ${Array(5).fill(0).map((_, i) => `<i class="fas fa-star${i < uni.rating ? '' : '-o'}"></i>`).join('')}
                    <span style="color: var(--text-light); margin-right: 8px;">${uni.tuition}</span>
                </div>
            </div>
        </div>
    `).join('');

    // Re-init scroll animations for new elements
    initScrollAnimations();
}

// Scholarships Functions
function initScholarships() {
    renderScholarships();
}

function renderScholarships() {
    const grid = document.getElementById('scholarshipsGrid');
    if (!grid) return;

    grid.innerHTML = scholarshipsData.map(sch => `
        <div class="scholarship-card fade-in">
            <div class="scholarship-header">
                <h3>${currentLang === 'ar' ? sch.nameAr : sch.name}</h3>
                <span class="scholarship-amount">${currentLang === 'ar' ? sch.amountAr : sch.amount}</span>
            </div>
            <p>${currentLang === 'ar' ? sch.descriptionAr : sch.description}</p>
            <div class="scholarship-meta">
                <span><i class="fas fa-calendar"></i> ${currentLang === 'ar' ? 'الموعد: ' + sch.deadlineAr : 'Deadline: ' + sch.deadline}</span>
                <span><i class="fas fa-globe"></i> ${currentLang === 'ar' ? sch.countryAr : sch.country}</span>
                <span><i class="fas fa-graduation-cap"></i> ${currentLang === 'ar' ? sch.levelAr : sch.level}</span>
            </div>
        </div>
    `).join('');

    initScrollAnimations();
}

// Search & Filter
function initSearchFilter() {
    const searchInput = document.getElementById('uniSearch');
    if (searchInput) {
        searchInput.addEventListener('input', renderUniversities);
    }

    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            renderUniversities();
        });
    });
}

// Counter Animation
function initCounters() {
    const counters = document.querySelectorAll('.counter');

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const counter = entry.target;
                const target = parseInt(counter.getAttribute('data-target'));
                animateCounter(counter, target);
                observer.unobserve(counter);
            }
        });
    }, { threshold: 0.5 });

    counters.forEach(counter => observer.observe(counter));
}

function animateCounter(element, target) {
    let current = 0;
    const increment = target / 50;
    const timer = setInterval(() => {
        current += increment;
        if (current >= target) {
            element.textContent = target + '+';
            clearInterval(timer);
        } else {
            element.textContent = Math.floor(current);
        }
    }, 30);
}

// Scroll Animations
function initScrollAnimations() {
    const elements = document.querySelectorAll('.fade-in');

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
            }
        });
    }, { threshold: 0.1 });

    elements.forEach(el => observer.observe(el));
}

// Navigation
function initNavigation() {
    const hamburger = document.querySelector('.hamburger');
    const navLinks = document.querySelector('.nav-links');

    if (hamburger) {
        hamburger.addEventListener('click', () => {
            navLinks.classList.toggle('active');
        });
    }

    // Smooth scroll for nav links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({ behavior: 'smooth', block: 'start' });
                navLinks.classList.remove('active');
            }
        });
    });

    // Navbar background on scroll
    window.addEventListener('scroll', () => {
        const navbar = document.querySelector('.navbar');
        if (window.scrollY > 100) {
            navbar.style.boxShadow = '0 2px 20px rgba(0,0,0,0.15)';
        } else {
            navbar.style.boxShadow = '0 2px 20px rgba(0,0,0,0.1)';
        }
    });
}

// Form Handling
function initFormHandling() {
    const form = document.getElementById('registrationForm');
    const success = document.getElementById('formSuccess');

    if (form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();

            // Get form data
            const formData = new FormData(form);
            const data = Object.fromEntries(formData);

            // Save to localStorage
            let applications = JSON.parse(localStorage.getItem('noval_applications') || '[]');
            data.id = Date.now();
            data.date = new Date().toLocaleString();
            applications.push(data);
            localStorage.setItem('noval_applications', JSON.stringify(applications));

            // Show success message
            form.classList.add('hidden');
            success.classList.remove('hidden');

            // Reset form after 5 seconds
            setTimeout(() => {
                form.reset();
                form.classList.remove('hidden');
                success.classList.add('hidden');
            }, 5000);

            // In production, you would send this data to a server
            console.log('Application submitted:', data);
        });
    }
}

// Export data for admin use
function exportApplications() {
    const applications = JSON.parse(localStorage.getItem('noval_applications') || '[]');
    return applications;
}

// Clear all applications (for admin use)
function clearApplications() {
    localStorage.removeItem('noval_applications');
}
